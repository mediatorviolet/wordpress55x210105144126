<div data-colibri-id="432-m10" class="h-row-container gutters-row-lg-0 gutters-row-md-0 gutters-row-0 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-0 style-550 style-local-432-m10 position-relative">
  <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-0 gutters-col-md-0 gutters-col-0 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-0">
    <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-551-outer style-local-432-m11-outer">
      <div data-colibri-id="432-m11" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-551 style-local-432-m11 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-auto align-self-lg-center align-self-md-center align-self-center">
          <div data-colibri-id="432-m12" class="h-text h-text-component style-552 style-local-432-m12 position-relative h-element">
            <div>
              <p>
                <?php esc_html_e('Categories:','colibri-wp'); ?>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="h-column h-column-container d-flex h-col-lg h-col-md h-col style-553-outer style-local-432-m13-outer">
      <div data-colibri-id="432-m13" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-553 style-local-432-m13 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
          <div data-colibri-id="432-m14" class="h-blog-categories style-554 style-local-432-m14 position-relative h-element">
            <div class="h-global-transition-all">
              <?php colibriwp_post_categories(array (
                'prefix' => '',
              )); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
