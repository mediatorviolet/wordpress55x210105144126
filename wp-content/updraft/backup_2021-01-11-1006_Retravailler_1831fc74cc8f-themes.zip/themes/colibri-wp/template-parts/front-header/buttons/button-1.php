<span class="h-button__outer style-26-outer style-local-7-h32-outer d-inline-flex h-element">
  <a h-use-smooth-scroll="true" href="<?php echo esc_url(\ColibriWP\Theme\View::getData( 'url' )); ?>" data-colibri-id="7-h32" class="d-flex w-100 align-items-center h-button justify-content-lg-center justify-content-md-center justify-content-center style-26 style-local-7-h32 position-relative">
    <span>
      <?php echo esc_html(\ColibriWP\Theme\View::getData( 'label' )); ?>
    </span>
  </a>
</span>
