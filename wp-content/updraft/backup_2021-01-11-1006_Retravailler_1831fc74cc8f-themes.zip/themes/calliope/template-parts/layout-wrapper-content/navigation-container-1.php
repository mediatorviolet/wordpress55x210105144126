<div data-colibri-id="16-m18" class="h-row-container gutters-row-lg-0 gutters-row-md-0 gutters-row-0 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-0 style-88 style-local-16-m18 position-relative">
  <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-0 gutters-col-md-0 gutters-col-0 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-0">
    <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-89-outer style-local-16-m19-outer">
      <div data-colibri-id="16-m19" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-89 style-local-16-m19 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
          <div data-colibri-id="16-m20" class="post-nav-button hide-title style-90 style-local-16-m20 position-relative h-element">
            <div class="h-global-transition-all">
              <?php colibriwp_post_nav_button(array (
                'type' => 'prev',
                'prev_post' => __('previous post', 'calliope'),
                'next_post' => __('Next post:', 'calliope'),
                'show_title' => false,
                'title_length' => 30,
              )); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-91-outer style-local-16-m21-outer">
      <div data-colibri-id="16-m21" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-91 style-local-16-m21 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
          <div data-colibri-id="16-m22" class="post-nav-button hide-title style-92 style-local-16-m22 position-relative h-element">
            <div class="h-global-transition-all">
              <?php colibriwp_post_nav_button(array (
                'type' => 'next',
                'prev_post' => __('Previous post:', 'calliope'),
                'next_post' => __('next post', 'calliope'),
                'show_title' => false,
                'title_length' => 30,
              )); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
