<div data-colibri-id="5-h30" class="h-x-container style-30 style-local-5-h30 position-relative h-element">
  <div class="h-x-container-inner style-dynamic-5-h30-group style-30-spacing style-local-5-h30-spacing">
    <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
    <?php $component->printButtons(); ?>
  </div>
</div>
