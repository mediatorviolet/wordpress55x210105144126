<div data-colibri-id="10-h24" class="style-56 style-local-10-h24 position-relative h-element">
  <div class="d-flex flex-wrap h-social-icons justify-content-lg-end justify-content-md-end justify-content-center">
    <?php $component = \ColibriWP\Theme\View::getData( "component" );  $component->printIcons(); ?>
  </div>
</div>
