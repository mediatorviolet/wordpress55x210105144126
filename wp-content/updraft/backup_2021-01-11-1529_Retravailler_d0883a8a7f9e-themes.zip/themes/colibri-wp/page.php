<?php get_header(); ?>
<?php colibriwp_theme()->get( 'content' )->render(); ?>
<?php get_footer();
